// CombatTracker - Sync defeated status among combatants that belong to the same token
export async function wrappedOnToggleDefeatedStatus(wrapped, combatant) {
  let isDefeated = !combatant.defeated;
  const otherCombatantsSharingToken = _getCombatantsSharingToken(combatant);
  wrapped(combatant);
  for (const cb of otherCombatantsSharingToken) {
    await cb.update({defeated: isDefeated});
  }
}

// Token - Highlight connected combatants when hovered
export function wrappedOnHoverIn(wrapped, event, options) {
  wrapped(event, options);
  const combatant = this.combatant;
  if (combatant) {
    const tracker = document.querySelector("#combat");
    if (tracker) {
      _getCombatantsSharingToken(combatant)
              .forEach(cb => {
                const li = tracker.querySelector(`.combatant[data-combatant-id="${cb.id}"]`);
                if (li)
                  li.classList.add("hover");
              });
    }
  }
}

// Token - Remove highlight of connected combatants when not hovered anymore
export function wrappedOnHoverOut(wrapped, event) {
  wrapped(event);

  const combatant = this.combatant;
  if (combatant) {
    const tracker = document.querySelector("#combat");
    if (tracker) {
      _getCombatantsSharingToken(combatant)
              .forEach(cb => {
                const li = tracker.querySelector(`.combatant[data-combatant-id="${cb.id}"]`);
                if (li)
                  li.classList.remove("hover");
              });
    }
  }
}

export function _getCombatantsSharingToken(combatant) {
  const combatantTokenIds = combatant.actor.getActiveTokens(false, true).map(t => t.id);
  return combatant.parent.combatants
          .filter(cb => combatantTokenIds.includes(cb.tokenId));
}

// CombatTracker - Add a Duplicate Combatant option
export function wrappedGetEntryContextOptions() {
  return [
    {
      name: "Duplicate Combatant",
      icon: '<i class="far fa-copy"></i>',
      callback: async (li) => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        this.combat.createEmbeddedDocuments("Combatant", [combatant]);
      }
    },
    {
      name: "COMBAT.CombatantUpdate",
      icon: '<i class="fas fa-edit"></i>',
      callback: this._onConfigureCombatant.bind(this)
    },
    {
      name: "COMBAT.CombatantClear",
      icon: '<i class="fas fa-undo"></i>',
      condition: li => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        return Number.isNumeric(combatant?.initiative);
      },
      callback: li => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        if (combatant)
          return combatant.update({initiative: null});
      }
    },
    {
      name: "COMBAT.CombatantReroll",
      icon: '<i class="fas fa-dice-d20"></i>',
      callback: li => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        if (combatant)
          return this.combat.rollInitiative([combatant.id]);
      }
    },
    {
      name: "COMBAT.CombatantRemove",
      icon: '<i class="fas fa-trash"></i>',
      callback: li => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        return combatant.delete();
      }
    },
    {
      name: "Remove All Duplicates",
      icon: '<i class="fas fa-trash"></i>',
      callback: li => {
        const combatant = this.combat.combatants.get(li.data("combatant-id"));
        _getCombatantsSharingToken(combatant)
                .forEach(c => c.delete());
        return true;
      }
    }
  ];
}
